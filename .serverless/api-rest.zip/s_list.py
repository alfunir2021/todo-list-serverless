import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='alfunir2021',
    application_name='todo-list-serverless',
    app_uid='XhJbpGNtRXLbD72KYD',
    org_uid='ee8ef250-6324-4eaf-bde5-e4c695510de9',
    deployment_uid='55f4c156-ed17-4a99-8b98-11b15afa0471',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.0.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-list', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/list.list')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
